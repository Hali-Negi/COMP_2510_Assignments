/*
 * Course: COMP 2510
 * Assignment: Assignment 2 - Project 2 (Recursion)
 * Name: Hali Imanpanah
 * Student ID: A01424306
 * Date: 2025-10-29
 * Description:
 *   Reads an integer from the user and uses a recursive function
 *   sumOfDigits(int n) to compute the sum of its digits (no loops).
 *   Example: 12345 -> 15.
 */

#include<stdio.h>
/*
 * Function: sumOfDigits
 *
 * Returns the sum of the decimal digits of n using recursion.
 * Base case: if n == 0, return 0.
 * Recursive step: lastDigit + sumOfDigits(rest).
 * Notes: if n is negative, convert it to positive first.
 */

 int sumOfDigits(int n) {
    if (n < 0) n= -n; // handle negatives
    if (n == 0) 
    return 0; // base case
    return (n % 10) + sumOfDigits(n / 10);
 }

 int main(void) {
    int n;

    printf("Enter a number: ");
    if (scanf("%d", &n) != 1) {
        printf("Invalid input.\n");
        return 1;
    }

    int result = sumOfDigits(n);
    printf(" Sum of digits = %d\n", result);

    return 0;
 }
