/*
 * Course: COMP 2510
 * Assignment: Assignment 2 - Project 1 (Bitwise Operations)
 * Name: Hali Imanpanah
 * Student ID: A01424306
 * Date: 2025-10-29
 * Description:
 *   This program asks the user to enter an integer, displays its 8-bit binary
 *   representation, and checks whether both the second and fourth bits
 *   (positions 1 and 3) are ON. It prints a message showing the binary form
 *   and whether those bits are ON or not.
 */
#include <stdio.h>

 /*
 * Function: areSecondAndFourthBitsOn
 * 
 * Checks if BOTH bit 1 and bit 3 are turned ON (set to 1).
 * Bit positions start from the right, counting from 0.
 *
 */
int areSecondAndFourthBitsOn(int n) {
    const int mask = 10;   
    return ((n & mask) == mask) ? 1 : 0;
}

void printBinary(int n) {
    for (int bit = 7; bit >= 0; --bit) {
        int on = (n >> bit) & 1;
        putchar(on ? '1' : '0');
    }
    putchar('\n');
}

/*
 * Function: main
 * 
 * The starting point of the program.
 * 1. Ask the user to enter a number.
 * 2. Print its 8-bit binary form.
 * 3. Tell whether the 2nd and 4th bits are ON.
 */

int main(void) {
    int n;

    printf("Enter an integer: ");
    scanf("%d", &n);

    printf("Binary: ");
    printBinary(n);

    if (areSecondAndFourthBitsOn(n)) {
        printf("Second and fourth bits are ON.\n");
    } else {
        printf("Second and fourth bits are NOT both ON.\n");
    }

    return 0;
}
